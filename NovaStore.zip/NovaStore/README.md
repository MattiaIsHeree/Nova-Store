# Nova Store 🖤

Store Android alternativo con estetica Nothing OS (nero OLED, angoli arrotondati,
animazioni "Glyph"), che pesca il catalogo da **F-Droid** — repository open source
pubblico e legale — invece che dal Play Store.

## Cosa fa davvero

- Legge l'indice ufficiale pubblico `https://f-droid.org/repo/index-v2.json`
- Mostra le app con icone, descrizioni, versione
- Scarica l'APK reale dai server F-Droid
- Apre l'installer di sistema Android per installarlo (richiede conferma
  dell'utente, come previsto dal sistema operativo — nessun modo legale di bypassarla)

## Cosa NON fa (e perché)

Non installa app a pagamento o gratuite dal **vero** Google Play Store senza
passare dall'app ufficiale. Farlo richiederebbe l'uso di API private di Google
(autenticazione con account, token interni, download diretto dai server Play) —
un'area non documentata, contro i Termini di Servizio di Google, e che apre
problemi seri di sicurezza (nessun controllo su cosa si installa) e legali.
Per questo il catalogo è F-Droid: stesso concept di "store alternativo con
UI tua", ma con contenuti legittimi e API pubbliche.

## Setup

1. Apri la cartella in Android Studio (Koala o più recente)
2. Sync Gradle
3. Esegui su un dispositivo/emulatore con API 26+
4. Al primo download, il sistema chiederà il permesso "Installa app sconosciute"
   per Nova Store — è normale, succede con qualsiasi store non-Play

## Note sulla velocità di download

Non c'è modo di rendere un download "più veloce del Play Store" per principio:
entrambi sono limitati dalla tua connessione e dal server sorgente. L'app usa
OkHttp con streaming a blocchi da 64KB, che è già efficiente quanto ragionevolmente
possibile lato client — il collo di bottiglia reale sarà quasi sempre la tua rete
o il CDN del server (i CDN di F-Droid sono generalmente veloci, ma variano).

## Architettura

```
MainActivity (NavHost) → StoreListScreen / AppDetailScreen
StoreViewModel → FDroidRepository (parsing streaming dell'indice)
              → DownloadInstallManager (download + Intent installer)
ui/theme      → palette OLED nera, forme squircle, tipografia mono
ui/components → DotMatrixLoader, MorphingInstallButton, staggered entrance
```

## Possibili estensioni

- Cache locale dell'indice su disco (Room) per avvii offline più veloci
- Filtri per categoria
- Notifica di sistema con progresso download invece che solo in-app
