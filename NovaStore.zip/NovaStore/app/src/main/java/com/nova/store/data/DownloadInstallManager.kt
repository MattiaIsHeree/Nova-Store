package com.nova.store.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.nova.store.data.model.FDroidApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream

/**
 * Scarica l'APK reale dal repository F-Droid (server ufficiali f-droid.org, CDN veloce)
 * e poi apre l'installer di sistema Android. La velocità di download dipende dalla tua
 * rete e dal server sorgente, esattamente come per il Play Store: non c'è un trucco per
 * renderla "più veloce" del limite fisico della connessione.
 */
class DownloadInstallManager(private val context: Context) {

    private val client = OkHttpClient.Builder().build()

    // 0f..1f progresso, -1f = errore, 2f = completato
    private val _progress = MutableStateFlow(0f)
    val progress: StateFlow<Float> = _progress

    suspend fun downloadApk(app: FDroidApp): File? = withContext(Dispatchers.IO) {
        try {
            _progress.value = 0f
            val request = Request.Builder().url(app.apkDownloadUrl).build()
            val response = client.newCall(request).execute()
            val body = response.body ?: return@withContext null

            val totalBytes = body.contentLength().takeIf { it > 0 } ?: app.sizeBytes
            val apkDir = File(context.cacheDir, "apks").apply { mkdirs() }
            val outFile = File(apkDir, "${app.packageName}_${app.versionCode}.apk")

            body.byteStream().use { input ->
                FileOutputStream(outFile).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var downloaded = 0L
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                        downloaded += read
                        if (totalBytes > 0) {
                            _progress.value = (downloaded.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                        }
                    }
                }
            }
            _progress.value = 2f
            outFile
        } catch (e: Exception) {
            _progress.value = -1f
            null
        }
    }

    /** Apre l'installer di sistema. L'utente deve confermare, come da comportamento Android standard. */
    fun launchInstaller(apkFile: File) {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            apkFile
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun resetProgress() {
        _progress.value = 0f
    }
}
