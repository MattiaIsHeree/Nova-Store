package com.nova.store.data.model

/**
 * Rappresenta una app catalogata su F-Droid (repository FOSS pubblico, non Play Store).
 * Viene popolata leggendo l'indice ufficiale https://f-droid.org/repo/index-v2.json
 */
data class FDroidApp(
    val packageName: String,
    val name: String,
    val summary: String,
    val description: String,
    val versionName: String,
    val versionCode: Long,
    val iconUrl: String,
    val apkFileName: String,
    val sizeBytes: Long,
    val license: String,
    val categories: List<String> = emptyList()
) {
    val apkDownloadUrl: String
        get() = "https://f-droid.org/repo/$apkFileName"
}

enum class DownloadState {
    IDLE, DOWNLOADING, READY_TO_INSTALL, INSTALLING, DONE, ERROR
}
