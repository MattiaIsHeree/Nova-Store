package com.nova.store.data.repository

import android.util.JsonReader
import com.nova.store.data.model.FDroidApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.InputStreamReader

/**
 * L'indice ufficiale F-Droid è pubblico e gratuito: https://f-droid.org/repo/index-v2.json
 * È grosso (decine di MB), quindi lo leggiamo in streaming con JsonReader invece
 * di caricarlo tutto in memoria. Nessuna API privata, nessun bypass: è lo stesso
 * indice che usa l'app ufficiale F-Droid.
 */
class FDroidRepository {

    private val client = OkHttpClient.Builder().build()
    private val indexUrl = "https://f-droid.org/repo/index-v2.json"

    // Cache in-memory della sessione: evitiamo di riscaricare l'indice a ogni scroll
    private var cachedApps: List<FDroidApp>? = null

    suspend fun getApps(forceRefresh: Boolean = false): List<FDroidApp> = withContext(Dispatchers.IO) {
        if (!forceRefresh && cachedApps != null) return@withContext cachedApps!!

        val request = Request.Builder().url(indexUrl).build()
        val response = client.newCall(request).execute()
        val body = response.body ?: return@withContext emptyList()

        val apps = mutableListOf<FDroidApp>()

        body.byteStream().use { stream ->
            val reader = JsonReader(InputStreamReader(stream, "UTF-8"))
            reader.beginObject()
            while (reader.hasNext()) {
                when (reader.nextName()) {
                    "packages" -> parsePackagesObject(reader, apps)
                    else -> reader.skipValue()
                }
            }
            reader.endObject()
        }

        cachedApps = apps
        apps
    }

    suspend fun search(query: String): List<FDroidApp> {
        val all = getApps()
        if (query.isBlank()) return all
        val q = query.trim().lowercase()
        return all.filter {
            it.name.lowercase().contains(q) || it.packageName.lowercase().contains(q) ||
                it.summary.lowercase().contains(q)
        }
    }

    // --- Parsing manuale della struttura index-v2 ---
    // Formato semplificato: packages -> { "<packageId>": { metadata: {...}, versions: {...} } }
    private fun parsePackagesObject(reader: JsonReader, out: MutableList<FDroidApp>) {
        reader.beginObject()
        while (reader.hasNext()) {
            val packageId = reader.nextName()
            var name = packageId
            var summary = ""
            var description = ""
            var iconUrl = ""
            var license = ""
            var bestVersionName = ""
            var bestVersionCode = 0L
            var bestApkName = ""
            var bestSize = 0L

            reader.beginObject()
            while (reader.hasNext()) {
                when (reader.nextName()) {
                    "metadata" -> {
                        reader.beginObject()
                        while (reader.hasNext()) {
                            when (reader.nextName()) {
                                "name" -> name = readLocalizedString(reader, default = packageId)
                                "summary" -> summary = readLocalizedString(reader, default = "")
                                "description" -> description = readLocalizedString(reader, default = "")
                                "license" -> license = if (reader.peek() == JsonReader.Token.STRING) reader.nextString() else run { reader.skipValue(); "" }
                                "icon" -> iconUrl = readLocalizedIcon(reader)
                                else -> reader.skipValue()
                            }
                        }
                        reader.endObject()
                    }
                    "versions" -> {
                        // prendiamo semplicemente la prima versione elencata (F-Droid le ordina dalla più recente)
                        reader.beginObject()
                        var first = true
                        while (reader.hasNext()) {
                            reader.nextName()
                            if (first) {
                                reader.beginObject()
                                while (reader.hasNext()) {
                                    when (reader.nextName()) {
                                        "manifest" -> {
                                            reader.beginObject()
                                            while (reader.hasNext()) {
                                                when (reader.nextName()) {
                                                    "versionName" -> bestVersionName = reader.nextString()
                                                    "versionCode" -> bestVersionCode = reader.nextLong()
                                                    else -> reader.skipValue()
                                                }
                                            }
                                            reader.endObject()
                                        }
                                        "file" -> {
                                            reader.beginObject()
                                            while (reader.hasNext()) {
                                                when (reader.nextName()) {
                                                    "name" -> bestApkName = reader.nextString().removePrefix("/")
                                                    "size" -> bestSize = reader.nextLong()
                                                    else -> reader.skipValue()
                                                }
                                            }
                                            reader.endObject()
                                        }
                                        else -> reader.skipValue()
                                    }
                                }
                                reader.endObject()
                                first = false
                            } else {
                                reader.skipValue()
                            }
                        }
                        reader.endObject()
                    }
                    else -> reader.skipValue()
                }
            }
            reader.endObject()

            if (bestApkName.isNotBlank()) {
                out.add(
                    FDroidApp(
                        packageName = packageId,
                        name = name,
                        summary = summary,
                        description = description,
                        versionName = bestVersionName,
                        versionCode = bestVersionCode,
                        iconUrl = iconUrl,
                        apkFileName = bestApkName,
                        sizeBytes = bestSize,
                        license = license
                    )
                )
            }
        }
        reader.endObject()
    }

    // I campi localizzati in index-v2 sono oggetti tipo { "en-US": "valore" }
    private fun readLocalizedString(reader: JsonReader, default: String): String {
        if (reader.peek() == JsonReader.Token.STRING) {
            return reader.nextString()
        }
        var result = default
        reader.beginObject()
        while (reader.hasNext()) {
            val lang = reader.nextName()
            val value = reader.nextString()
            if (lang == "en-US" || result == default) result = value
        }
        reader.endObject()
        return result
    }

    private fun readLocalizedIcon(reader: JsonReader): String {
        var path = ""
        reader.beginObject()
        while (reader.hasNext()) {
            reader.nextName()
            reader.beginObject()
            while (reader.hasNext()) {
                when (reader.nextName()) {
                    "name" -> path = reader.nextString()
                    else -> reader.skipValue()
                }
            }
            reader.endObject()
        }
        reader.endObject()
        return if (path.isNotBlank()) "https://f-droid.org/repo$path" else ""
    }
}
