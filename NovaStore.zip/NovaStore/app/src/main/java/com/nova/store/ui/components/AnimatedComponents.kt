package com.nova.store.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.nova.store.data.model.DownloadState
import com.nova.store.ui.theme.DotRed
import com.nova.store.ui.theme.SuccessGreen
import kotlin.math.cos
import kotlin.math.sin

/**
 * Griglia di puntini che pulsa in stile "Glyph Interface" mentre l'app è in caricamento.
 * Ogni puntino si accende con un ritardo a cascata, come un'onda.
 */
@Composable
fun DotMatrixLoader(modifier: Modifier = Modifier, dotCount: Int = 5) {
    val infinite = rememberInfiniteTransition(label = "dotmatrix")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing)
        ),
        label = "phase"
    )

    Canvas(modifier = modifier.size(56.dp)) {
        val spacing = size.width / dotCount
        for (i in 0 until dotCount) {
            val localPhase = phase - i * 0.6f
            val scale = (sin(localPhase) * 0.5f + 0.5f).coerceIn(0.25f, 1f)
            drawCircle(
                color = DotRed.copy(alpha = 0.4f + 0.6f * scale),
                radius = (spacing / 2.6f) * scale,
                center = Offset(spacing * i + spacing / 2, size.height / 2)
            )
        }
    }
}

/**
 * Il bottone di download/installazione: parte come pillola "Installa", durante il download
 * si trasforma in un anello di progresso circolare con morph fluido, poi in una spunta verde.
 * Nessuna libreria esterna: solo Canvas + animateFloatAsState.
 */
@Composable
fun MorphingInstallButton(
    state: DownloadState,
    progress: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val width by animateDpAsState(
        targetValue = if (state == DownloadState.IDLE) 108.dp else 44.dp,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "widthMorph"
    )
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "progress"
    )
    val bounce = rememberInfiniteTransition(label = "bounce")
    val pulse by bounce.animateFloat(
        initialValue = 1f,
        targetValue = if (state == DownloadState.DOWNLOADING) 1.08f else 1f,
        animationSpec = infiniteRepeatable(tween(500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    Box(
        modifier = modifier
            .height(44.dp)
            .width(width)
            .scale(if (state == DownloadState.DOWNLOADING) pulse else 1f)
            .clip(CircleShape)
            .background(
                when (state) {
                    DownloadState.DONE -> SuccessGreen.copy(alpha = 0.18f)
                    DownloadState.ERROR -> Color.Red.copy(alpha = 0.18f)
                    else -> DotRed
                }
            )
            .clickable(enabled = state == DownloadState.IDLE || state == DownloadState.ERROR) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        when (state) {
            DownloadState.IDLE -> Text(
                "INSTALLA",
                style = MaterialTheme.typography.labelLarge,
                color = Color.White
            )
            DownloadState.DOWNLOADING, DownloadState.READY_TO_INSTALL, DownloadState.INSTALLING -> {
                CircularProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier.size(22.dp),
                    color = Color.White,
                    strokeWidth = 2.5.dp,
                    strokeCap = StrokeCap.Round
                )
            }
            DownloadState.DONE -> Icon(
                Icons.Filled.Check,
                contentDescription = "Installato",
                tint = SuccessGreen,
                modifier = Modifier.size(20.dp)
            )
            DownloadState.ERROR -> Icon(
                Icons.Filled.Download,
                contentDescription = "Riprova",
                tint = Color.Red,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/** Anima l'ingresso di un elemento della lista con fade + slide, a cascata in base all'indice. */
@Composable
fun rememberStaggeredEntrance(index: Int): State<Float> {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(index) {
        kotlinx.coroutines.delay(index * 35L)
        anim.animateTo(
            1f,
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)
        )
    }
    return anim.asState()
}
