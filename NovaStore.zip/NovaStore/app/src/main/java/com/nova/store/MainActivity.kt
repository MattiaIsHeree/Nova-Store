package com.nova.store

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nova.store.data.model.FDroidApp
import com.nova.store.ui.screens.AppDetailScreen
import com.nova.store.ui.screens.StoreListScreen
import com.nova.store.ui.theme.NovaStoreTheme

class MainActivity : ComponentActivity() {

    private val viewModel: StoreViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NovaStoreTheme {
                NovaNavGraph(viewModel)
            }
        }
    }
}

@Composable
fun NovaNavGraph(viewModel: StoreViewModel) {
    val navController = rememberNavController()
    // Teniamo l'app selezionata in memoria per passarla al dettaglio senza serializzarla
    var selectedApp by remember { mutableStateOf<FDroidApp?>(null) }

    NavHost(
        navController = navController,
        startDestination = "list",
        enterTransition = { fadeIn(tween(280)) + scaleIn(initialScale = 0.96f, animationSpec = tween(280)) },
        exitTransition = { fadeOut(tween(200)) },
        popEnterTransition = { fadeIn(tween(280)) },
        popExitTransition = { fadeOut(tween(200)) + scaleOut(targetScale = 0.96f, animationSpec = tween(200)) }
    ) {
        composable("list") {
            StoreListScreen(
                viewModel = viewModel,
                onAppClick = { app ->
                    selectedApp = app
                    navController.navigate("detail")
                }
            )
        }
        composable("detail") {
            selectedApp?.let { app ->
                AppDetailScreen(
                    app = app,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
