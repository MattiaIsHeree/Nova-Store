package com.nova.store.ui.theme

import androidx.compose.ui.graphics.Color

// OLED true-black base, ispirato a Nothing OS
val OledBlack = Color(0xFF000000)
val CardSurface = Color(0xFF121212)
val CardSurfaceElevated = Color(0xFF1C1C1C)
val DotRed = Color(0xFFFF3B30)          // accento "Glyph"
val NearWhite = Color(0xFFF5F5F0)
val MutedGray = Color(0xFF8A8A8A)
val DividerGray = Color(0xFF2A2A2A)
val SuccessGreen = Color(0xFF4CD964)
