package com.nova.store

import android.app.Application
import com.nova.store.data.repository.FDroidRepository

class NovaStoreApp : Application() {
    val repository by lazy { FDroidRepository() }
}
