package com.nova.store.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val NovaDarkColorScheme = darkColorScheme(
    primary = DotRed,
    onPrimary = NearWhite,
    secondary = MutedGray,
    background = OledBlack,
    onBackground = NearWhite,
    surface = CardSurface,
    onSurface = NearWhite,
    surfaceVariant = CardSurfaceElevated,
    onSurfaceVariant = MutedGray,
    outline = DividerGray,
    error = DotRed
)

@Composable
fun NovaStoreTheme(
    darkTheme: Boolean = true, // sempre scuro: è OLED black, è la sua ragione di vita
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        val window = (view.context as android.app.Activity).window
        window.statusBarColor = OledBlack.toArgb()
        window.navigationBarColor = OledBlack.toArgb()
        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
    }

    MaterialTheme(
        colorScheme = NovaDarkColorScheme,
        shapes = NovaShapes,
        typography = NovaTypography,
        content = content
    )
}
