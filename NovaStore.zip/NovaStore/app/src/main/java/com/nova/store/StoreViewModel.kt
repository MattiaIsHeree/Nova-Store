package com.nova.store

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.store.data.DownloadInstallManager
import com.nova.store.data.model.DownloadState
import com.nova.store.data.model.FDroidApp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class StoreUiState(
    val isLoading: Boolean = true,
    val apps: List<FDroidApp> = emptyList(),
    val query: String = "",
    val error: String? = null
)

class StoreViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as NovaStoreApp).repository
    private val downloadManager = DownloadInstallManager(application)

    private val _uiState = MutableStateFlow(StoreUiState())
    val uiState: StateFlow<StoreUiState> = _uiState.asStateFlow()

    private val _downloadStates = MutableStateFlow<Map<String, DownloadState>>(emptyMap())
    val downloadStates: StateFlow<Map<String, DownloadState>> = _downloadStates.asStateFlow()

    val downloadProgress = downloadManager.progress

    init {
        loadApps()
    }

    fun loadApps(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            try {
                val apps = repository.getApps(forceRefresh)
                _uiState.value = _uiState.value.copy(isLoading = false, apps = apps)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "Impossibile contattare i server F-Droid. Controlla la connessione."
                )
            }
        }
    }

    fun onQueryChange(query: String) {
        _uiState.value = _uiState.value.copy(query = query)
        viewModelScope.launch {
            val results = repository.search(query)
            _uiState.value = _uiState.value.copy(apps = results)
        }
    }

    fun downloadAndInstall(app: FDroidApp) {
        viewModelScope.launch {
            setState(app.packageName, DownloadState.DOWNLOADING)
            downloadManager.resetProgress()
            val file = downloadManager.downloadApk(app)
            if (file == null) {
                setState(app.packageName, DownloadState.ERROR)
                return@launch
            }
            setState(app.packageName, DownloadState.READY_TO_INSTALL)
            downloadManager.launchInstaller(file)
            setState(app.packageName, DownloadState.DONE)
        }
    }

    private fun setState(packageName: String, state: DownloadState) {
        _downloadStates.value = _downloadStates.value.toMutableMap().apply {
            put(packageName, state)
        }
    }
}
