package com.nova.store.ui.screens

import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.nova.store.StoreViewModel
import com.nova.store.data.model.DownloadState
import com.nova.store.data.model.FDroidApp
import com.nova.store.ui.components.DotMatrixLoader
import com.nova.store.ui.components.MorphingInstallButton
import com.nova.store.ui.components.rememberStaggeredEntrance
import com.nova.store.ui.theme.CardSurface
import com.nova.store.ui.theme.DotRed
import com.nova.store.ui.theme.IconShape
import com.nova.store.ui.theme.MutedGray
import com.nova.store.ui.theme.PillShape

@Composable
fun StoreListScreen(
    viewModel: StoreViewModel,
    onAppClick: (FDroidApp) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val downloadStates by viewModel.downloadStates.collectAsState()
    val progress by viewModel.downloadProgress.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            "NOVA STORE",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            "Catalogo open source · powered by F-Droid",
            style = MaterialTheme.typography.bodyMedium,
            color = MutedGray
        )
        Spacer(Modifier.height(20.dp))

        SearchBar(query = uiState.query, onQueryChange = viewModel::onQueryChange)
        Spacer(Modifier.height(16.dp))

        when {
            uiState.isLoading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        DotMatrixLoader()
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Sincronizzazione catalogo...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedGray
                        )
                    }
                }
            }
            uiState.error != null -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(uiState.error!!, color = MutedGray, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(12.dp))
                        FilledTonalButton(onClick = { viewModel.loadApps(true) }) {
                            Text("Riprova")
                        }
                    }
                }
            }
            else -> {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(uiState.apps, key = { it.packageName }) { app ->
                        val index = uiState.apps.indexOf(app)
                        val entrance by rememberStaggeredEntrance(index)
                        AppRow(
                            app = app,
                            state = downloadStates[app.packageName] ?: DownloadState.IDLE,
                            progress = if (downloadStates[app.packageName] == DownloadState.DOWNLOADING) progress else 0f,
                            onClick = { onAppClick(app) },
                            onInstall = { viewModel.downloadAndInstall(app) },
                            modifier = Modifier
                                .alpha(entrance)
                                .graphicsLayer {
                                    translationY = (1f - entrance) * 40f
                                }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchBar(query: String, onQueryChange: (String) -> Unit) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        placeholder = { Text("Cerca app...", color = MutedGray) },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = MutedGray) },
        singleLine = true,
        shape = PillShape,
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = CardSurface,
            unfocusedContainerColor = CardSurface,
            focusedBorderColor = DotRed,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun AppRow(
    app: FDroidApp,
    state: DownloadState,
    progress: Float,
    onClick: () -> Unit,
    onInstall: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(CardSurface)
            .clickable { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = app.iconUrl,
            contentDescription = app.name,
            modifier = Modifier
                .size(52.dp)
                .clip(IconShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
        )
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                app.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
            Text(
                app.summary,
                style = MaterialTheme.typography.bodyMedium,
                color = MutedGray,
                maxLines = 1
            )
        }
        Spacer(Modifier.width(8.dp))
        MorphingInstallButton(
            state = state,
            progress = progress,
            onClick = onInstall
        )
    }
}
