package com.nova.store.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.nova.store.StoreViewModel
import com.nova.store.data.model.DownloadState
import com.nova.store.data.model.FDroidApp
import com.nova.store.ui.components.MorphingInstallButton
import com.nova.store.ui.theme.CardSurface
import com.nova.store.ui.theme.IconShape
import com.nova.store.ui.theme.MutedGray

@Composable
fun AppDetailScreen(
    app: FDroidApp,
    viewModel: StoreViewModel,
    onBack: () -> Unit
) {
    val downloadStates by viewModel.downloadStates.collectAsState()
    val progress by viewModel.downloadProgress.collectAsState()
    val state = downloadStates[app.packageName] ?: DownloadState.IDLE

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Indietro", tint = MaterialTheme.colorScheme.onBackground)
        }

        Spacer(Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = app.iconUrl,
                contentDescription = app.name,
                modifier = Modifier
                    .size(84.dp)
                    .clip(IconShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(app.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(app.packageName, style = MaterialTheme.typography.bodyMedium, color = MutedGray, maxLines = 1)
                Spacer(Modifier.height(6.dp))
                Text("v${app.versionName} · ${app.license}", style = MaterialTheme.typography.bodyMedium, color = MutedGray)
            }
        }

        Spacer(Modifier.height(20.dp))

        MorphingInstallButton(
            state = state,
            progress = if (state == DownloadState.DOWNLOADING) progress else 0f,
            onClick = { viewModel.downloadAndInstall(app) },
            modifier = Modifier.fillMaxWidth(0.4f)
        )

        Spacer(Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(CardSurface)
                .padding(18.dp)
        ) {
            Column {
                Text("Descrizione", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    app.description.ifBlank { app.summary },
                    style = MaterialTheme.typography.bodyLarge,
                    color = MutedGray
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "Distribuita tramite F-Droid, repository open source indipendente da Google Play.",
            style = MaterialTheme.typography.bodyMedium,
            color = MutedGray
        )
    }
}
